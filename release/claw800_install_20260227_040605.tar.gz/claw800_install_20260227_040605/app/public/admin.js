const loginCard = document.getElementById('loginCard');
const panelCard = document.getElementById('panelCard');
const loginForm = document.getElementById('loginForm');
const loginPasswordInput = document.getElementById('loginPasswordInput');
const loginMessage = document.getElementById('loginMessage');
const adminList = document.getElementById('adminList');
const listTitle = document.getElementById('listTitle');
const adminAddForm = document.getElementById('adminAddForm');
const adminMessage = document.getElementById('adminMessage');
const adminImportForm = document.getElementById('adminImportForm');
const importMessage = document.getElementById('importMessage');
const adminCategorySelect = document.getElementById('adminCategorySelect');
const adminLangZhBtn = document.getElementById('adminLangZhBtn');
const adminLangEnBtn = document.getElementById('adminLangEnBtn');
const adminSearchInput = document.getElementById('adminSearchInput');
const adminSearchToolbar = document.getElementById('adminSearchToolbar');
const adminAddSection = document.getElementById('adminAddSection');
const adminImportSection = document.getElementById('adminImportSection');
const adminCategoryAddSection = document.getElementById('adminCategoryAddSection');
const adminCategoryListSection = document.getElementById('adminCategoryListSection');
const adminListSection = document.getElementById('adminListSection');
const categoryAddForm = document.getElementById('categoryAddForm');
const categoryMessage = document.getElementById('categoryMessage');
const categoryList = document.getElementById('categoryList');

const FIXED_CATEGORIES = [
  'AI 与大语言模型',
  '开发与编码',
  'DevOps 与云',
  '浏览器与网页自动化',
  '营销与销售',
  '生产力与工作流',
  '搜索与研究',
  '通信与社交',
  '媒体与内容',
  '金融与加密货币',
  '健康与健身',
  '安全与监控',
  '自动化与实用工具',
  '业务运营',
  '代理协调'
];

const CATEGORY_EN = {
  'AI 与大语言模型': 'AI & Large Language Models',
  '开发与编码': 'Development & Coding',
  'DevOps 与云': 'DevOps & Cloud',
  '浏览器与网页自动化': 'Browser & Web Automation',
  '营销与销售': 'Marketing & Sales',
  '生产力与工作流': 'Productivity & Workflows',
  '搜索与研究': 'Search & Research',
  '通信与社交': 'Communication & Social',
  '媒体与内容': 'Media & Content',
  '金融与加密货币': 'Finance & Crypto',
  '健康与健身': 'Health & Fitness',
  '安全与监控': 'Security & Monitoring',
  '自动化与实用工具': 'Automation & Utilities',
  '业务运营': 'Business Operations',
  '代理协调': 'Agent Orchestration'
};

const texts = {
  zh: {
    htmlLang: 'zh-CN',
    title: 'claw800 后台',
    loginTitle: '管理员登录',
    loginPasswordLabel: '密码',
    loginBtn: '登录',
    panelTitle: '审核后台',
    navAdd: '手动新增',
    navImport: '批量导入',
    navCategoryList: '分类列表',
    navCategoryAdd: '新增分类',
    navPending: '等待审核',
    navApproved: '已上线',
    logoutBtn: '退出',
    searchPlaceholder: '搜索已上线网站（名称/网址/简介/分类）',
    searchBtn: '搜索',
    clearSearchBtn: '清空',
    adminAddTitle: '手动新增站点',
    adminLabelName: '网站名称',
    adminLabelUrl: '网站地址',
    adminLabelDesc: '简介',
    adminLabelCategory: '分类',
    adminLabelSort: '排序',
    adminAddBtn: '直接上线',
    importTitle: '批量导入（JSON）',
    importLabel: '粘贴 JSON 数组',
    importBtn: '批量导入并上线',
    categoriesAddTitle: '新增分类',
    categoriesListTitle: '分类列表',
    categoryNameLabel: '分类名称',
    categorySortLabel: '排序',
    categoryEnabledLabel: '启用',
    categoryAddBtn: '新增分类',
    categorySaveBtn: '保存分类',
    categoryDeleteBtn: '删除分类',
    categoryDeleteConfirm: '确定删除这个分类吗？',
    categoryDeleted: '分类已删除',
    categorySiteCount: '收录网站数',
    enabledYes: '是',
    enabledNo: '否',
    pendingTitle: '待审核列表',
    approvedTitle: '已上线列表',
    empty: '暂无记录',
    category: '分类',
    source: '来源',
    submitter: '投稿人',
    unknown: '未分类',
    approve: '通过',
    reject: '驳回',
    edit: '编辑',
    sort: '排序',
    saveSort: '保存排序',
    rejectPrompt: '请输入驳回原因（可留空）',
    editNamePrompt: '编辑网站名称',
    editUrlPrompt: '编辑网站地址',
    editDescPrompt: '编辑简介',
    editCategoryPrompt: '编辑分类（可填写以下任一分类）',
    editSaved: '保存成功',
    sortSaved: '排序已更新',
    operationFailed: '操作失败',
    loginFailed: '登录失败',
    createFailed: '创建失败',
    createSuccess: '已新增并上线',
    importFailed: '导入失败',
    importJsonError: 'JSON 格式错误，需要数组格式',
    importSuccess: (i, s) => `导入完成：新增 ${i} 条，跳过 ${s} 条`,
    sourceMap: {
      admin: '后台添加',
      user_submit: '用户投稿',
      seed_openclaw: 'OpenClaw 首批',
      admin_import: '后台导入'
    }
  },
  en: {
    htmlLang: 'en',
    title: 'claw800 Admin',
    loginTitle: 'Admin Login',
    loginPasswordLabel: 'Password',
    loginBtn: 'Login',
    panelTitle: 'Review Console',
    navAdd: 'Add Website',
    navImport: 'Bulk Import',
    navCategoryList: 'Category List',
    navCategoryAdd: 'Add Category',
    navPending: 'Pending',
    navApproved: 'Approved',
    logoutBtn: 'Logout',
    searchPlaceholder: 'Search approved websites (name/URL/description/category)',
    searchBtn: 'Search',
    clearSearchBtn: 'Clear',
    adminAddTitle: 'Add Website Manually',
    adminLabelName: 'Website Name',
    adminLabelUrl: 'Website URL',
    adminLabelDesc: 'Description',
    adminLabelCategory: 'Category',
    adminLabelSort: 'Sort',
    adminAddBtn: 'Publish Now',
    importTitle: 'Bulk Import (JSON)',
    importLabel: 'Paste JSON Array',
    importBtn: 'Import and Publish',
    categoriesAddTitle: 'Add Category',
    categoriesListTitle: 'Category List',
    categoryNameLabel: 'Category Name',
    categorySortLabel: 'Sort',
    categoryEnabledLabel: 'Enabled',
    categoryAddBtn: 'Add Category',
    categorySaveBtn: 'Save Category',
    categoryDeleteBtn: 'Delete',
    categoryDeleteConfirm: 'Delete this category?',
    categoryDeleted: 'Category deleted.',
    categorySiteCount: 'Website Count',
    enabledYes: 'Yes',
    enabledNo: 'No',
    pendingTitle: 'Pending Review',
    approvedTitle: 'Approved Websites',
    empty: 'No records.',
    category: 'Category',
    source: 'Source',
    submitter: 'Submitter',
    unknown: 'Uncategorized',
    approve: 'Approve',
    reject: 'Reject',
    edit: 'Edit',
    sort: 'Sort',
    saveSort: 'Save Sort',
    rejectPrompt: 'Enter rejection reason (optional)',
    editNamePrompt: 'Edit website name',
    editUrlPrompt: 'Edit website URL',
    editDescPrompt: 'Edit description',
    editCategoryPrompt: 'Edit category (use one of the listed tags)',
    editSaved: 'Saved successfully.',
    sortSaved: 'Sort updated.',
    operationFailed: 'Operation failed',
    loginFailed: 'Login failed',
    createFailed: 'Create failed',
    createSuccess: 'Website added and published.',
    importFailed: 'Import failed',
    importJsonError: 'Invalid JSON format. Expected an array.',
    importSuccess: (i, s) => `Import done: added ${i}, skipped ${s}`,
    sourceMap: {
      admin: 'Admin Added',
      user_submit: 'User Submission',
      seed_openclaw: 'OpenClaw Seed',
      admin_import: 'Admin Import'
    }
  }
};

let currentStatus = 'pending';
let currentLang = localStorage.getItem('claw800_lang') === 'en' ? 'en' : 'zh';
let currentItems = [];
let currentQuery = '';
let currentView = 'pending';
let managedCategories = [];

function t(key) {
  return texts[currentLang][key];
}

function focusLoginPassword() {
  setTimeout(() => {
    loginPasswordInput?.focus();
    loginPasswordInput?.select();
  }, 0);
}

function escapeHtml(str) {
  return String(str || '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function categoryLabel(category) {
  if (!category) return t('unknown');
  if (currentLang === 'en') return CATEGORY_EN[category] || category;
  return category;
}

function sourceLabel(source) {
  return texts[currentLang].sourceMap[source] || source;
}

function normalizeCategoryInput(raw) {
  const val = String(raw || '').trim();
  const enabled = managedCategories.filter((item) => item.is_enabled).map((item) => item.name);
  if (!val) return enabled[0] || 'AI 与大语言模型';
  if (enabled.includes(val)) return val;
  const found = Object.entries(CATEGORY_EN).find(([, en]) => en.toLowerCase() === val.toLowerCase());
  return found ? found[0] : val;
}

function localizeApiError(message) {
  if (currentLang !== 'en') return message;
  if (typeof message === 'string' && message.startsWith('该分类收录了')) {
    const m = message.match(/(\d+)/);
    const n = m ? m[1] : '';
    return `This category has ${n} website records and cannot be deleted.`;
  }
  const map = {
    Unauthorized: 'Unauthorized.',
    '密码错误': 'Incorrect password.',
    'name 和 url 必填': 'Name and URL are required.',
    'url 格式不正确': 'Invalid URL format.',
    'name 必填': 'Name is required.',
    '标签已存在': 'Category already exists.',
    '分类已存在': 'Category already exists.',
    '网站已存在': 'Website already exists.',
    '创建失败': 'Create failed.',
    '更新失败': 'Update failed.',
    'sortOrder 必须是数字': 'sortOrder must be a number.',
    '记录不存在': 'Record not found.',
    'JSON 格式错误，需要数组格式': 'Invalid JSON format. Expected an array.',
    '导入失败': 'Import failed.'
  };
  return map[message] || message;
}

function renderAdminCategoryOptions() {
  const enabled = managedCategories.filter((item) => item.is_enabled).map((item) => item.name);
  const categories = enabled.length ? enabled : FIXED_CATEGORIES;
  adminCategorySelect.innerHTML = categories
    .map((category) => `<option value="${escapeHtml(category)}">${escapeHtml(categoryLabel(category))}</option>`)
    .join('');
}

function renderCategoryList() {
  if (!managedCategories.length) {
    categoryList.innerHTML = `<p class="empty">${escapeHtml(t('empty'))}</p>`;
    return;
  }

  categoryList.innerHTML = managedCategories
    .map(
      (item) => `
      <article class="review-card">
        <p class="small">${escapeHtml(t('categorySiteCount'))}：${Number(item.site_count || 0)}</p>
        <div class="toolbar sort-row">
          <label class="small">${escapeHtml(t('categoryNameLabel'))}
            <input id="catName-${item.id}" value="${escapeHtml(item.name)}" ${item.id < 0 ? 'disabled' : ''} />
          </label>
          <label class="small">${escapeHtml(t('categorySortLabel'))}
            <input id="catSort-${item.id}" type="number" value="${Number(item.sort_order || 0)}" ${item.id < 0 ? 'disabled' : ''} />
          </label>
          <label class="small">${escapeHtml(t('categoryEnabledLabel'))}
            <select id="catEnabled-${item.id}" ${item.id < 0 ? 'disabled' : ''}>
              <option value="1" ${item.is_enabled ? 'selected' : ''}>${escapeHtml(t('enabledYes'))}</option>
              <option value="0" ${item.is_enabled ? '' : 'selected'}>${escapeHtml(t('enabledNo'))}</option>
            </select>
          </label>
          ${
            item.id < 0
              ? `<span class="small">${escapeHtml(currentLang === 'en' ? 'Readonly (restart backend to edit)' : '只读（重启后端后可编辑）')}</span>`
              : `<button type="button" onclick="saveCategoryConfig(${item.id})">${escapeHtml(t('categorySaveBtn'))}</button>
                 <button type="button" class="danger" onclick="deleteCategoryConfig(${item.id})">${escapeHtml(
                   t('categoryDeleteBtn')
                 )}</button>`
          }
        </div>
      </article>
    `
    )
    .join('');
}

async function loadAdminCategories() {
  try {
    const res = await fetch('/api/admin/categories');
    if (res.status === 401) return;
    if (!res.ok) throw new Error('admin categories unavailable');
    const data = await res.json();
    managedCategories = data.items || [];
  } catch {
    // Fallback: if admin categories API is unavailable, still show current frontend categories.
    const res = await fetch('/api/categories');
    if (!res.ok) return;
    const data = await res.json();
    managedCategories = (data.items || []).map((item, idx) => ({
      id: -(idx + 1),
      name: item.category,
      sort_order: idx,
      is_enabled: 1,
      site_count: Number(item.count || 0)
    }));
  }

  renderAdminCategoryOptions();
  renderCategoryList();
}

function applyLanguage() {
  const dict = texts[currentLang];
  document.documentElement.lang = dict.htmlLang;
  document.title = dict.title;

  document.getElementById('loginTitle').textContent = dict.loginTitle;
  document.getElementById('loginPasswordLabel').childNodes[0].textContent = dict.loginPasswordLabel;
  document.getElementById('loginBtn').textContent = dict.loginBtn;
  document.getElementById('panelTitle').textContent = dict.panelTitle;
  document.getElementById('navAdd').textContent = dict.navAdd;
  document.getElementById('navImport').textContent = dict.navImport;
  document.getElementById('navCategoryList').textContent = dict.navCategoryList;
  document.getElementById('navCategoryAdd').textContent = dict.navCategoryAdd;
  document.getElementById('navPending').textContent = dict.navPending;
  document.getElementById('navApproved').textContent = dict.navApproved;
  document.getElementById('logoutBtn').textContent = dict.logoutBtn;
  adminSearchInput.placeholder = dict.searchPlaceholder;
  document.getElementById('adminSearchBtn').textContent = dict.searchBtn;
  document.getElementById('adminClearSearchBtn').textContent = dict.clearSearchBtn;
  document.getElementById('adminAddTitle').textContent = dict.adminAddTitle;
  document.getElementById('adminLabelName').childNodes[0].textContent = dict.adminLabelName;
  document.getElementById('adminLabelUrl').childNodes[0].textContent = dict.adminLabelUrl;
  document.getElementById('adminLabelDesc').childNodes[0].textContent = dict.adminLabelDesc;
  document.getElementById('adminLabelCategory').childNodes[0].textContent = dict.adminLabelCategory;
  document.getElementById('adminLabelSort').childNodes[0].textContent = dict.adminLabelSort;
  document.getElementById('adminAddBtn').textContent = dict.adminAddBtn;
  document.getElementById('importTitle').textContent = dict.importTitle;
  document.getElementById('importLabel').childNodes[0].textContent = dict.importLabel;
  document.getElementById('importBtn').textContent = dict.importBtn;
  document.getElementById('categoriesAddTitle').textContent = dict.categoriesAddTitle;
  document.getElementById('categoriesListTitle').textContent = dict.categoriesListTitle;
  document.getElementById('categoryNameLabel').childNodes[0].textContent = dict.categoryNameLabel;
  document.getElementById('categorySortLabel').childNodes[0].textContent = dict.categorySortLabel;
  document.getElementById('categoryEnabledLabel').childNodes[0].textContent = dict.categoryEnabledLabel;
  document.getElementById('categoryAddBtn').textContent = dict.categoryAddBtn;
  const enabledSelect = document.querySelector('#categoryEnabledLabel select');
  if (enabledSelect) {
    enabledSelect.options[0].textContent = dict.enabledYes;
    enabledSelect.options[1].textContent = dict.enabledNo;
  }

  adminLangZhBtn.classList.toggle('active', currentLang === 'zh');
  adminLangEnBtn.classList.toggle('active', currentLang === 'en');

  renderAdminCategoryOptions();
  renderCategoryList();
  setView(currentView);
}

function setView(view) {
  currentView = view;
  adminAddSection.classList.toggle('hidden', view !== 'add');
  adminImportSection.classList.toggle('hidden', view !== 'import');
  adminCategoryAddSection.classList.toggle('hidden', view !== 'category-add');
  adminCategoryListSection.classList.toggle('hidden', view !== 'category-list');
  adminListSection.classList.toggle('hidden', view !== 'pending' && view !== 'approved');
  adminSearchToolbar.classList.toggle('hidden', view !== 'approved');

  if (view === 'add' || view === 'category-add' || view === 'category-list') {
    loadAdminCategories();
  }

  if (view === 'pending') {
    currentQuery = '';
    adminSearchInput.value = '';
    loadList('pending');
  } else if (view === 'approved') {
    loadList('approved');
  }
}

async function login(password) {
  const res = await fetch('/api/admin/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password })
  });

  const data = await res.json();
  if (!res.ok) throw new Error(localizeApiError(data.error || t('loginFailed')));
}

async function loadList(status = 'pending') {
  currentStatus = status;
  listTitle.textContent = status === 'pending' ? t('pendingTitle') : t('approvedTitle');

  const params = new URLSearchParams({ status });
  if (currentQuery) params.set('q', currentQuery);

  const res = await fetch(`/api/admin/sites?${params.toString()}`);
  if (res.status === 401) {
    loginCard.classList.remove('hidden');
    panelCard.classList.add('hidden');
    focusLoginPassword();
    return;
  }

  const data = await res.json();
  let items = data.items;

  if (currentQuery) {
    const kw = currentQuery.toLowerCase();
    items = items.filter((site) => {
      const haystack = `${site.name} ${site.url} ${site.description || ''} ${site.category || ''}`.toLowerCase();
      return haystack.includes(kw);
    });
  }

  currentItems = items;

  if (!items.length) {
    adminList.innerHTML = `<p class="empty">${escapeHtml(t('empty'))}</p>`;
    return;
  }

  adminList.innerHTML = items
    .map(
      (site) => `
      <article class="review-card">
        <h3>${escapeHtml(site.name)}</h3>
        <p><a href="${escapeHtml(site.url)}" target="_blank" rel="noopener">${escapeHtml(site.url)}</a></p>
        <p>${escapeHtml(site.description || '')}</p>
        <p class="small">${escapeHtml(t('category'))}：${escapeHtml(categoryLabel(site.category))} | ${escapeHtml(
          t('source')
        )}：${escapeHtml(sourceLabel(site.source))}</p>
        ${
          status === 'pending'
            ? `<p class="small">${escapeHtml(t('submitter'))}：${escapeHtml(site.submitter_name || '-')} / ${escapeHtml(
                site.submitter_email || '-'
              )}</p>
               <div class="toolbar sort-row">
                <label class="small">${escapeHtml(t('sort'))}
                  <input id="pendingSortInput-${site.id}" type="number" value="${Number(site.sort_order || 0)}" />
                </label>
               </div>`
            : `<div class="toolbar sort-row">
                <label class="small">${escapeHtml(t('sort'))}
                  <input id="sortInput-${site.id}" type="number" value="${Number(site.sort_order || 0)}" />
                </label>
                <button type="button" onclick="saveSort(${site.id})">${escapeHtml(t('saveSort'))}</button>
              </div>`
        }
        ${
          status === 'pending'
            ? `<div class="review-actions">
                <button onclick="approveSite(${site.id})">${escapeHtml(t('approve'))}</button>
                <button class="danger" onclick="rejectSite(${site.id})">${escapeHtml(t('reject'))}</button>
              </div>`
            : `<div class="review-actions">
                <button onclick="editSite(${site.id})">${escapeHtml(t('edit'))}</button>
              </div>`
        }
      </article>
    `
    )
    .join('');
}

window.approveSite = async function approveSite(id) {
  const pendingSortInput = document.getElementById(`pendingSortInput-${id}`);
  const sortOrder = Number(pendingSortInput?.value);
  const payload = { sortOrder: Number.isFinite(sortOrder) ? sortOrder : 0 };
  const res = await fetch(`/api/admin/sites/${id}/approve`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!res.ok) {
    alert(t('operationFailed'));
    return;
  }
  loadList(currentStatus);
};

window.rejectSite = async function rejectSite(id) {
  const note = prompt(t('rejectPrompt')) || '';
  const res = await fetch(`/api/admin/sites/${id}/reject`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ note })
  });
  if (!res.ok) {
    alert(t('operationFailed'));
    return;
  }
  loadList(currentStatus);
};

window.editSite = async function editSite(id) {
  const site = currentItems.find((item) => item.id === id);
  if (!site) {
    alert(t('operationFailed'));
    return;
  }

  const name = prompt(t('editNamePrompt'), site.name);
  if (name === null) return;
  const url = prompt(t('editUrlPrompt'), site.url);
  if (url === null) return;
  const description = prompt(t('editDescPrompt'), site.description || '');
  if (description === null) return;
  const categoryNames = managedCategories.length ? managedCategories.map((item) => item.name) : FIXED_CATEGORIES;
  const categoryTip = `\n${categoryNames.join('\n')}`;
  const categoryInput = prompt(`${t('editCategoryPrompt')}${categoryTip}`, site.category || categoryNames[0]);
  if (categoryInput === null) return;

  const payload = {
    name: name.trim(),
    url: url.trim(),
    description: description.trim(),
    category: normalizeCategoryInput(categoryInput)
  };

  const res = await fetch(`/api/admin/sites/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  const data = await res.json();
  if (!res.ok) {
    alert(localizeApiError(data.error || t('operationFailed')));
    return;
  }

  alert(t('editSaved'));
  loadList(currentStatus);
};

window.saveSort = async function saveSort(id) {
  const input = document.getElementById(`sortInput-${id}`);
  const sortOrder = Number(input?.value);

  if (!Number.isFinite(sortOrder)) {
    alert(localizeApiError('sortOrder 必须是数字'));
    return;
  }

  const res = await fetch(`/api/admin/sites/${id}/sort`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ sortOrder })
  });

  const data = await res.json();
  if (!res.ok) {
    alert(localizeApiError(data.error || t('operationFailed')));
    return;
  }

  alert(t('sortSaved'));
  loadList(currentStatus);
};

window.saveCategoryConfig = async function saveCategoryConfig(id) {
  const name = String(document.getElementById(`catName-${id}`)?.value || '').trim();
  const sortOrder = Number(document.getElementById(`catSort-${id}`)?.value || 0);
  const isEnabled = Number(document.getElementById(`catEnabled-${id}`)?.value || 0);

  const res = await fetch(`/api/admin/categories/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, sortOrder, isEnabled })
  });
  const data = await res.json();
  if (!res.ok) {
    alert(localizeApiError(data.error || t('operationFailed')));
    return;
  }

  await loadAdminCategories();
  alert(t('editSaved'));
};

window.deleteCategoryConfig = async function deleteCategoryConfig(id) {
  const item = managedCategories.find((x) => x.id === id);
  const siteCount = Number(item?.site_count || 0);
  if (siteCount > 0) {
    alert(`该分类收录了 ${siteCount} 个网站，不允许删除`);
    return;
  }

  if (!confirm(t('categoryDeleteConfirm'))) return;

  const res = await fetch(`/api/admin/categories/${id}`, { method: 'DELETE' });
  const data = await res.json();
  if (!res.ok) {
    alert(localizeApiError(data.error || t('operationFailed')));
    return;
  }

  await loadAdminCategories();
  alert(t('categoryDeleted'));
};

loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  loginMessage.textContent = '';
  const password = new FormData(loginForm).get('password');

  try {
    await login(password);
    loginCard.classList.add('hidden');
    panelCard.classList.remove('hidden');
    setView('pending');
  } catch (err) {
    loginMessage.textContent = err.message || t('loginFailed');
    loginMessage.className = 'message error';
  }
});

adminAddForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  adminMessage.textContent = '';

  const payload = Object.fromEntries(new FormData(adminAddForm).entries());
  const res = await fetch('/api/admin/sites', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  const data = await res.json();

  if (!res.ok) {
    adminMessage.textContent = localizeApiError(data.error || t('createFailed'));
    adminMessage.className = 'message error';
    return;
  }

  adminMessage.textContent = t('createSuccess');
  adminMessage.className = 'message success';
  adminAddForm.reset();
  renderAdminCategoryOptions();
  loadList(currentStatus);
});

adminImportForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  importMessage.textContent = '';

  const raw = new FormData(adminImportForm).get('json');
  let items;
  try {
    items = JSON.parse(String(raw || '[]'));
    if (!Array.isArray(items)) throw new Error();
  } catch {
    importMessage.textContent = t('importJsonError');
    importMessage.className = 'message error';
    return;
  }

  const res = await fetch('/api/admin/import', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ items })
  });

  const data = await res.json();
  if (!res.ok) {
    importMessage.textContent = localizeApiError(data.error || t('importFailed'));
    importMessage.className = 'message error';
    return;
  }

  importMessage.textContent = t('importSuccess')(data.imported, data.skipped);
  importMessage.className = 'message success';
  loadList(currentStatus);
});

categoryAddForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  categoryMessage.textContent = '';
  const payload = Object.fromEntries(new FormData(categoryAddForm).entries());

  const res = await fetch('/api/admin/categories', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await res.json();
  if (!res.ok) {
    categoryMessage.textContent = localizeApiError(data.error || t('createFailed'));
    categoryMessage.className = 'message error';
    return;
  }

  categoryMessage.textContent = t('createSuccess');
  categoryMessage.className = 'message success';
  categoryAddForm.reset();
  categoryAddForm.querySelector('input[name="sortOrder"]').value = '0';
  categoryAddForm.querySelector('select[name="isEnabled"]').value = '1';
  await loadAdminCategories();
});

document.getElementById('adminSearchBtn').addEventListener('click', () => {
  currentQuery = adminSearchInput.value.trim();
  loadList('approved');
});

document.getElementById('adminClearSearchBtn').addEventListener('click', () => {
  adminSearchInput.value = '';
  currentQuery = '';
  loadList('approved');
});

adminSearchInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    currentQuery = adminSearchInput.value.trim();
    loadList('approved');
  }
});

document.getElementById('navAdd').addEventListener('click', () => setView('add'));
document.getElementById('navImport').addEventListener('click', () => setView('import'));
document.getElementById('navCategoryList').addEventListener('click', () => setView('category-list'));
document.getElementById('navCategoryAdd').addEventListener('click', () => setView('category-add'));
document.getElementById('navPending').addEventListener('click', () => setView('pending'));
document.getElementById('navApproved').addEventListener('click', () => setView('approved'));
document.getElementById('logoutBtn').addEventListener('click', async () => {
  await fetch('/api/admin/logout', { method: 'POST' });
  loginCard.classList.remove('hidden');
  panelCard.classList.add('hidden');
  focusLoginPassword();
});

adminLangZhBtn.addEventListener('click', () => {
  currentLang = 'zh';
  localStorage.setItem('claw800_lang', currentLang);
  applyLanguage();
});

adminLangEnBtn.addEventListener('click', () => {
  currentLang = 'en';
  localStorage.setItem('claw800_lang', currentLang);
  applyLanguage();
});

applyLanguage();
focusLoginPassword();
